const menuBtn = document.getElementById('menuBtn');
    const navlinks = document.getElementById('navlinks');
    menuBtn.addEventListener('click', () => navlinks.classList.toggle('open'));

    // Theme toggle (persist)
    const themeToggle = document.getElementById('themeToggle');
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') document.documentElement.classList.add('light');
    themeToggle.addEventListener('click', () => {
      document.documentElement.classList.toggle('light');
      localStorage.setItem('theme', document.documentElement.classList.contains('light') ? 'light' : 'dark');
    });